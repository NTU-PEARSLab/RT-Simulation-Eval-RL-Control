%Eric Tsai, 蔡東衡 2025/12/17
%Katherine A. Kim 2025/04/09
%Darsana Deo  2024/02/05
%National Taiwan University, Electrical Engineering, PEARS Lab

clear all;

%data range updates
n=0:0.001:432;
m_a=114:0.001:393;
m_b=87:0.001:390;
m_c=102:0.001:372;
m_d=96:0.001:381;
m_e=87:0.001:345;

%Changing simulation time to real time
tstart1 = 0.0001;
tend1 = 0.9999999;
t1 = tstart1:[(tend1-tstart1)/(size(n,2)-1)]:tend1;
a1 = (size(n,2)-1)/6; % for whole day

tstart_a = 0.2639;
tend_a = 0.9097;
t_a = tstart_a:[(tend_a-tstart_a)/(size(m_a,2)-1)]:tend_a;
a_a = (size(m_a,2)-1)/6;%for simulated time span

tstart_b = 0.2014;
tend_b = 0.9028;
t_b = tstart_b:[(tend_b-tstart_b)/(size(m_b,2)-1)]:tend_b;
a_b = (size(m_b,2)-1)/6;%for simulated time span

tstart_c = 0.236111111111;
tend_c = 0.861111111111;
t_c = tstart_c:[(tend_c-tstart_c)/(size(m_c,2)-1)]:tend_c;
a_c = (size(m_c,2)-1)/6;%for simulated time span

tstart_d = 0.2222;
tend_d = 0.8750;
t_d = tstart_d:[(tend_d-tstart_d)/(size(m_d,2)-1)]:tend_d;
a_d = (size(m_d,2)-1)/6;%for simulated time span

tstart_e = 0.2014;
tend_e = 0.79861111;
t_e = tstart_e:[(tend_e-tstart_e)/(size(m_e,2)-1)]:tend_e;
a_e = (size(m_e,2)-1)/6; %for simulated time span


%% Load power CSV
gridata1 = readmatrix('gridPowerday1.csv'); 
gridpower1_csv = gridata1(:,2);   
gridata2 = readmatrix('gridPowerday2.csv'); 
gridpower2_csv = gridata2(:,2);   
gridata3 = readmatrix('gridPowerday3.csv'); 
gridpower3_csv = gridata3(:,2);   
gridata4 = readmatrix('gridPowerday4.csv'); 
gridpower4_csv = gridata4(:,2);   
gridata5 = readmatrix('gridPowerday5.csv'); 
gridpower5_csv = gridata5(:,2);   
batdata1 = readmatrix('batteryPowerday1.csv'); 
batpower1_csv = batdata1(:,2);   
batdata2 = readmatrix('batteryPowerday2.csv'); 
batpower2_csv = batdata2(:,2);   
batdata3 = readmatrix('batteryPowerday3.csv'); 
batpower3_csv = batdata3(:,2);   
batdata4 = readmatrix('batteryPowerday4.csv'); 
batpower4_csv = batdata4(:,2);   
batdata5 = readmatrix('batteryPowerday5.csv'); 
batpower5_csv = batdata5(:,2);   
origgrid_len1 = length(gridpower1_csv);
origgrid_len2 = length(gridpower2_csv);
origgrid_len3 = length(gridpower3_csv);
origgrid_len4 = length(gridpower4_csv);
origgrid_len5 = length(gridpower5_csv);
origbat_len1 = length(batpower1_csv);
origbat_len2 = length(batpower2_csv);
origbat_len3 = length(batpower3_csv);
origbat_len4 = length(batpower4_csv);
origbat_len5 = length(batpower5_csv);
%% Adjust power length
target_len1 =length(t_a);
target_len2 =length(t_b);
target_len3 =length(t_c);
target_len4 =length(t_d);
target_len5 =length(t_e);
x_target1 = linspace(0, 1, target_len1);
x_target2 = linspace(0, 1, target_len2);
x_target3 = linspace(0, 1, target_len3);
x_target4 = linspace(0, 1, target_len4);
x_target5 = linspace(0, 1, target_len5);
x_origgrid1 = linspace(0, 1, origgrid_len1);
x_origgrid2 = linspace(0, 1, origgrid_len2);
x_origgrid3 = linspace(0, 1, origgrid_len3);
x_origgrid4 = linspace(0, 1, origgrid_len4);
x_origgrid5 = linspace(0, 1, origgrid_len5);
x_origbat1 = linspace(0, 1, origbat_len1);
x_origbat2 = linspace(0, 1, origbat_len2);
x_origbat3 = linspace(0, 1, origbat_len3);
x_origbat4 = linspace(0, 1, origbat_len4);
x_origbat5 = linspace(0, 1, origbat_len5);
Pgrid1 = interp1(x_origgrid1, gridpower1_csv, x_target1, 'linear');
Pgrid2 = interp1(x_origgrid2, gridpower2_csv, x_target2, 'linear');
Pgrid3 = interp1(x_origgrid3, gridpower3_csv, x_target3, 'linear');
Pgrid4 = interp1(x_origgrid4, gridpower4_csv, x_target4, 'linear');
Pgrid5 = interp1(x_origgrid5, gridpower5_csv, x_target5, 'linear');
Pbat1 = interp1(x_origbat1, batpower1_csv, x_target1, 'linear');
Pbat2 = interp1(x_origbat2, batpower2_csv, x_target2, 'linear');
Pbat3 = interp1(x_origbat3, batpower3_csv, x_target3, 'linear');
Pbat4 = interp1(x_origbat4, batpower4_csv, x_target4, 'linear');
Pbat5 = interp1(x_origbat5, batpower5_csv, x_target5, 'linear');
figure(1)
tiledlayout(5,1, 'Padding','compact', 'TileSpacing','compact')

% ── Day 1 ──
nexttile
plot(t_a(4500:end), Pgrid1(4500:end), 'Color', [0, 0, 0.7]); hold on
plot(t_a(4500:end), Pbat1(4500:end), 'Color', [0, 0, 1]);
%ylabel('Power [W]')
legend('Grid Power','Battery Power','Location','northeast','FontSize',11)
%title('4^{th} January (Tuesday)')
text(min(xlim), min(ylim), sprintf('Jan 4'), 'Horiz','left', 'Vert','bottom')
set(gca, 'XTick', [], 'XLim', [0.2 0.92], 'YLim', [-150 210])

% ── Day 2 ──
nexttile
plot(t_b(4500:end), Pgrid2(4500:end), 'Color', [0.7, 0, 0]); hold on
plot(t_b(4500:end), Pbat2(4500:end), 'Color', [1, 0, 0]);
%ylabel('Power [W]')
legend('Grid Power','Battery Power','Location','northeast','FontSize',11)
%title('12^{th} April (Tuesday)')
text(min(xlim), min(ylim), sprintf('Apr 12'), 'Horiz','left', 'Vert','bottom')
set(gca, 'XTick', [], 'XLim', [0.2 0.92], 'YLim', [-150 210])

% ── Day 3 ──
nexttile
plot(t_c(4500:end), Pgrid3(4500:end), 'Color', [0.8, 0.8, 0]); hold on
plot(t_c(4500:end), Pbat3(4500:end),  'Color', [0.5, 0.5, 0]);
ylabel('Power [W]')
legend('Grid Power','Battery Power','Location','northeast','FontSize',11)
%title('14^{th} May (Saturday)')
text(min(xlim), min(ylim), sprintf('May 14'), 'Horiz','left', 'Vert','bottom')
set(gca, 'XTick', [], 'XLim', [0.2 0.92], 'YLim', [-150 210])

% ── Day 4 ──
nexttile
plot(t_d(4500:end), Pgrid4(4500:end), 'Color', [0.8, 0, 0.8]); hold on
plot(t_d(4500:end), Pbat4(4500:end),  'Color', [0.5, 0, 0.5]);
%ylabel('Power [W]')
legend('Grid Power','Battery Power','Location','northeast','FontSize',11)
%title('14^{th} June (Tuesday)')
text(min(xlim), min(ylim), sprintf('Jun 14'), 'Horiz','left', 'Vert','bottom')
set(gca, 'XTick', [], 'XLim', [0.2 0.92], 'YLim', [-150 210])

% ── Day 5 ──
nexttile
plot(t_e(4500:end), Pgrid5(4500:end), 'Color', [0, 0.7, 0]); hold on
plot(t_e(4500:end), Pbat5(4500:end),  'Color', [0, 0.5, 0]);
%ylabel('Power [W]')
xlabel('Time [hour]')
legend('Grid Power','Battery Power','Location','northeast','FontSize',11)
%title('24^{th} June (Friday)')
text(min(xlim), min(ylim), sprintf('Jun 24'), 'Horiz','left', 'Vert','bottom')
xticks([t1(1), t1(a1+1), t1(2*a1+1), t1(3*a1+1), t1(4*a1+1), t1(5*a1+1), t1(6*a1+1)]);
xticklabels({'00:00','04:00','08:00','12:00','16:00','20:00','23:59'});
set(gca, 'XLim', [0.2 0.92], 'YLim', [-150 210])
