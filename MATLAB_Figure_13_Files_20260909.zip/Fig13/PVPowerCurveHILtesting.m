%Eric Tsai, 蔡東衡 2025/12/17
%Katherine A. Kim 2025/04/09
%Darsana Deo  2024/02/05
%National Taiwan University, Electrical Engineering, PEARS Lab

clear all;

%Journal picture showing real-time simulation PV Power results
% Required Data
PVdata1 = readmatrix('PVPowerday1.csv'); 
PV1_csv = PVdata1(:,2);   
PVdata2 = readmatrix('PVPowerday2.csv'); 
PV2_csv = PVdata2(:,2);   
PVdata3 = readmatrix('PVPowerday3.csv'); 
PV3_csv = PVdata3(:,2);   
PVdata4 = readmatrix('PVPowerday4.csv'); 
PV4_csv = PVdata4(:,2);   
PVdata5 = readmatrix('PVPowerday5.csv'); 
PV5_csv = PVdata5(:,2);   

%Ppv figures
figure(1)
orig_len1 = length(PV1_csv);
orig_len2 = length(PV2_csv);
orig_len3 = length(PV3_csv);
orig_len4 = length(PV4_csv);
orig_len5 = length(PV5_csv);
target_len1 =length(t_a);
target_len2 =length(t_b);
target_len3 =length(t_c);
target_len4 =length(t_d);
target_len5 =length(t_e);
x_target1 = linspace(0, 1, target_len1);
x_target2 = linspace(0, 1, target_len2);
x_target3 = linspace(0, 1, target_len3);
x_target4 = linspace(0, 1, target_len4);
x_target5 = linspace(0, 1, target_len5);
x_orig1 = linspace(0, 1, orig_len1);
x_orig2 = linspace(0, 1, orig_len2);
x_orig3 = linspace(0, 1, orig_len3);
x_orig4 = linspace(0, 1, orig_len4);
x_orig5 = linspace(0, 1, orig_len5);

PV1 = interp1(x_orig1, PV1_csv, x_target1, 'linear');
PV2 = interp1(x_orig2, PV2_csv, x_target2, 'linear');
PV3 = interp1(x_orig3, PV3_csv, x_target3, 'linear');
PV4 = interp1(x_orig4, PV4_csv, x_target4, 'linear');
PV5 = interp1(x_orig5, PV5_csv, x_target5, 'linear');
plot(t_a, PV1) 
hold on
plot(t_b(1533:end), PV2(1533:end)) 
hold on
plot(t_c(1616:end), PV3(1616:end)) 
hold on
plot(t_d(1533:end), PV4(1533:end)) 
hold on
plot(t_e, PV5) 

xlabel('Time [hour]')
ylabel('Simulated PV power [W]')
legend('4^{th} January (Tuesday)','12^{th} April (Tuesday)','14^{th} May (Saturday)','14^{th} June (Tuesday)','24^{th} June (Friday)','Location','southwest','Orientation','horizontal','NumColumns',2)
xticks([t1(1), t1(a1+1), t1(2*a1+1), t1(3*a1+1), t1(4*a1+1), t1(5*a1+1), t1(6*a1+1)]);
xticklabels(datestr([t1(1), t1(a1+1), t1(2*a1+1), t1(3*a1+1), t1(4*a1+1), t1(5*a1+1), t1(6*a1+1)], 'HH:MM'));
ylim([-5,300])
xlim([0.22,0.8])
